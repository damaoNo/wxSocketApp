#!/bin/bash

# Epel installation script

sudo yum -y install epel-release




sudo yum -y install openssl
sudo yum -y install telnet
sudo yum -y install sqlite
  
for i in *.rpm ; do

  sudo yum -y install ${i}
  ER=$?
  if ! [ ${ER} -eq 0 ] ; then
    sudo rpm -Uvh ${i}
    ER=$?
    if ! [ ${ER} -eq 0 ] ; then
      sudo rpm -ivh --force ${i}
      ER=$?
      if ! [ ${ER} -eq 0 ] ; then
        echo "ERROR: cannot install package ${i}"
        exit -1
      fi
    fi
  fi
done

echo SUCCESS !

